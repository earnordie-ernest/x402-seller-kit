# x402 Seller Kit — sell any API per call in USDC on Base

This kit is the exact, tested stack I use to run a paid x402 API in production
(4 live endpoints, settled on Base mainnet). Deploy it in ~10 minutes.

## What you get
- worker.js  — a Cloudflare Worker that serves paid x402 endpoints on Base mainnet
               (USDC 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913, network eip155:8453),
               issues a spec-correct 402 (v2 PAYMENT-REQUIRED header + bazaar extension),
               settles through a keyless facilitator (PayAI first, xpay fallback),
               and ships FREE discovery files: /health, /openapi.json, /.well-known/x402.
- deploy_worker.py — one-command deploy (CF API token + account id).
- check_list / README — the tested facilitator table and gotchas.

## Measured facts baked in (save you days)
- The ONLY keyless, Base-mainnet, exact-scheme facilitators that settle today:
  facilitator.payai.network and facilitator.xpay.sh. x402.org / x402.rs are TESTNET.
- Discovery is facilitator-mediated. To be listed in a Bazaar you must (a) publish the
  bazaar extension in your 402 and (b) settle through PayAI or CDP. Settling alone is
  NOT indexing (measured: 16k+ resources indexed, settled sellers still absent).
- Registries that accept a permanent URL with no email/Post: x402scan (SIWX wallet login)
  and 402index.io. Tunnel URLs (trycloudflare) are REJECTED — use *.workers.dev.

## Quickstart
1. `export CLOUDFLARE_API_TOKEN=... ; python3 deploy_worker.py <account_id>`
2. Edit the PAID map + BAZAAR examples in worker.js for your own endpoints.
3. Register your origin: x402scan SIWX (sign in with your seller wallet) + 402index POST.
4. Get paid: buyers send `PAYMENT-SIGNATURE` (x402 v2) and you settle per call.

MIT-licensed starting point. Build something agents pay for.
