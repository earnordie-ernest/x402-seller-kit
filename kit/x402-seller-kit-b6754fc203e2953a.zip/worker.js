/**
 * x402-probe — Cloudflare Worker edition (permanent URL, no server, no gas).
 *
 * Free endpoints:
 *   GET /health
 *   GET /.well-known/x402        (v1 discovery)
 *   GET /.well-known/x402.json   (v2 manifest, Bazaar-ish)
 *   GET /openapi.json            (what x402scan reads first)
 * Paid endpoints (x402 `exact`, USDC on Base, settle via facilitator.xpay.sh):
 *   GET /probe?url=<endpoint>    decode any endpoint's x402 price/network/payTo without paying it
 *   GET /price/ETH               ETH/USD spot price
 *
 * The seller needs no ETH: the facilitator broadcasts the settlement.
 */

const PAY_TO = "0xEe523a5145cfaEa8cCEc34Fb364a2A92Fad62A3a";
const NETWORK = "eip155:8453";
const FACILITATOR = "https://facilitator.xpay.sh";
const PRICE = "$0.001";
const ASSET = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"; // USDC on Base
const AMOUNT_ATOMIC = "1000"; // 0.001 USDC
const MAX_TIMEOUT = 300;

const PAID = {
  "/probe": "Decode any x402 endpoint's price, network, asset and payTo",
  "/price/ETH": "ETH/USD spot price",
  "/fetch": "Fetch any public web page and return clean readable text + title + links (for LLM agents)",
  "/wiki": "Wikipedia summary of any topic: title, plain-text extract and canonical URL (for LLM agents)",
};

function b64encode(obj) {
  const s = JSON.stringify(obj);
  const bytes = new TextEncoder().encode(s);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}
function b64decode(str) {
  const bin = atob(str.replace(/-/g, "+").replace(/_/g, "/"));
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return JSON.parse(new TextDecoder().decode(bytes));
}

const BAZAAR = {
  "/probe": { method: "GET", q: { url: "https://hermes.swap.io/v1/swap/quote" }, ex: { ok: true, status: 402, accepts: [{ network: "eip155:8453", amount_usd: 0.01, payTo: "0x..." }] }, tags: ["x402", "probe", "pricing", "tools"] },
  "/fetch": { method: "GET", q: { url: "https://example.com" }, ex: { ok: true, title: "Example Domain", text: "This domain is for use in...", links: [] }, tags: ["web", "fetch", "scrape", "markdown", "llm"] },
  "/price/ETH": { method: "GET", q: {}, ex: { symbol: "ETH/USD", spot: { amount: "3000.00" } }, tags: ["crypto", "price", "eth"] },
  "/wiki": { method: "GET", q: { q: "x402" }, ex: { ok: true, title: "x402", extract: "x402 is an open standard for internet-native payments...", url: "https://en.wikipedia.org/wiki/X402", source: "wikipedia" }, tags: ["wiki", "facts", "knowledge", "research", "llm"] },
};

function challenge(url, description) {
  const path = new URL(url).pathname;
  const b = BAZAAR[path];
  const ch = {
    x402Version: 2,
    resource: { url, description, mimeType: "application/json" },
    accepts: [
      {
        scheme: "exact",
        network: NETWORK,
        asset: ASSET,
        amount: AMOUNT_ATOMIC,
        payTo: PAY_TO,
        maxTimeoutSeconds: MAX_TIMEOUT,
        extra: { name: "USD Coin", version: "2" },
      },
    ],
  };
  if (b) {
    ch.extensions = {
      bazaar: {
        info: { input: { type: "http", method: b.method, queryParams: b.q }, output: { type: "json", example: b.ex } },
        schema: {
          $schema: "https://json-schema.org/draft/2020-12/schema",
          type: "object",
          properties: {
            input: { type: "object", properties: { type: { type: "string", const: "http" }, method: { type: "string", enum: ["GET", "POST"] }, queryParams: { type: "object", properties: Object.fromEntries(Object.keys(b.q).map((k) => [k, { type: "string", description: "target URL" }])), required: Object.keys(b.q) } }, required: ["type", "method"] },
            output: { type: "object" },
          },
          required: ["input"],
        },
      },
    };
    ch.resource.serviceName = "Ernest x402 tools";
    ch.resource.tags = b.tags;
  }
  return ch;
}

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-expose-headers": "PAYMENT-REQUIRED,PAYMENT-RESPONSE",
};

function json(body, status = 200, extra = {}) {
  return new Response(JSON.stringify(body, null, 1), {
    status,
    headers: { "content-type": "application/json", ...CORS, ...extra },
  });
}

function paymentRequired(ch) {
  return json(ch, 402, {
    "payment-required": b64encode(ch),
    "x-payment-required": b64encode(ch),
  });
}

async function decodeChallenge(value) {
  const out = { raw_header_present: !!value };
  try {
    const padded = value + "=".repeat((4 - (value.length % 4)) % 4);
    const doc = b64decode(padded);
    out.x402Version = doc.x402Version;
    const res = doc.resource || {};
    out.resource = { url: res.url, description: res.description };
    out.accepts = (doc.accepts || []).map((a) => {
      let usd = null;
      try {
        usd = a.amount ? Number(a.amount) / 1e6 : null;
      } catch (e) {}
      return {
        scheme: a.scheme,
        network: a.network,
        asset: a.asset,
        amount_atomic: a.amount,
        amount_usd: usd,
        payTo: a.payTo || a.pay_to,
        maxTimeoutSeconds: a.maxTimeoutSeconds,
      };
    });
  } catch (e) {
    out.decode_error = String(e).slice(0, 200);
  }
  return out;
}

async function wikiSummary(q, lang) {
  lang = (lang || "en").replace(/[^a-z\-]/g, "").slice(0, 6) || "en";
  const H = { "User-Agent": "x402-probe/1.5 (ernest-earnordie@agentmail.to)" };
  const api = "https://" + lang + ".wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=" + encodeURIComponent(q);
  const d = await (await fetch(api, { headers: H })).json();
  const pages = d.query && d.query.pages ? Object.values(d.query.pages) : [];
  const p = pages[0] || {};
  if (!p.extract) {
    const sd = await (await fetch("https://" + lang + ".wikipedia.org/w/api.php?action=query&format=json&list=search&srlimit=3&srsearch=" + encodeURIComponent(q), { headers: H })).json();
    return { ok: false, error: "no exact page", suggestions: ((sd.query && sd.query.search) || []).map(function (x) { return { title: x.title, snippet: x.snippet }; }) };
  }
  return { ok: true, title: p.title, extract: String(p.extract).slice(0, 4000), url: "https://" + lang + ".wikipedia.org/wiki/" + encodeURIComponent(String(p.title).replace(/ /g, "_")), source: "wikipedia" };
}

function isBlockedHost(host) {
  return (
    /^(localhost|127\.|0\.|10\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host) ||
    host.endsWith(".local") ||
    host.endsWith(".internal")
  );
}

async function fetchClean(target) {
  let u;
  try { u = new URL(target); } catch (e) { return { ok: false, error: "invalid url" }; }
  if (u.protocol !== "https:" && u.protocol !== "http:") return { ok: false, error: "unsupported scheme" };
  if (isBlockedHost(u.hostname)) return { ok: false, error: "refusing private host" };
  let res;
  try {
    res = await fetch(u.toString(), { headers: { "user-agent": "Mozilla/5.0 (compatible; x402-fetch/1.0)", accept: "text/html,application/xhtml+xml,text/plain,*/*" }, redirect: "follow" });
  } catch (e) { return { ok: false, error: "fetch failed: " + String(e).slice(0, 150) }; }
  const ct = res.headers.get("content-type") || "";
  let raw = await res.text();
  if (raw.length > 2000000) raw = raw.slice(0, 2000000);
  if (!/html|xml/i.test(ct)) {
    return { ok: true, url: res.url, status: res.status, content_type: ct, title: null, text: raw.slice(0, 100000), links: [] };
  }
  const title = ((raw.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || "").trim();
  const links = [];
  const re = /<a\s[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(raw)) && links.length < 100) {
    try { links.push({ href: new URL(m[1], res.url).toString(), text: m[2].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 120) }); } catch (e) {}
  }
  let t = raw
    .replace(/<(script|style|noscript|svg|head|iframe)[\s\S]*?<\/\1>/gi, " ")
    .replace(/<h([1-6])[^>]*>/gi, (x, n) => "\n\n" + "#".repeat(Number(n)) + " ")
    .replace(/<li[^>]*>/gi, "\n- ")
    .replace(/<(br|\/p|\/div|\/h[1-6]|\/tr|\/li|p|div|tr)[^>]*>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, " ").replace(/\n\s*\n\s*\n+/g, "\n\n").trim();
  return { ok: true, url: res.url, status: res.status, content_type: ct, title, text: t.slice(0, 100000), truncated: t.length > 100000, links };
}

async function probeTarget(target) {
  let u;
  try {
    u = new URL(target);
  } catch (e) {
    return { ok: false, error: "invalid url" };
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") return { ok: false, error: "unsupported scheme" };
  if (isBlockedHost(u.hostname)) return { ok: false, error: "refusing private host" };
  let res;
  try {
    res = await fetch(u.toString(), { headers: { accept: "application/json" }, redirect: "manual" });
  } catch (e) {
    return { ok: false, error: "fetch failed: " + String(e).slice(0, 150) };
  }
  const hdr =
    res.headers.get("payment-required") ||
    res.headers.get("PAYMENT-REQUIRED") ||
    res.headers.get("x-payment");
  const out = { ok: true, probed_url: u.toString(), status: res.status };
  if (res.status === 402) {
    if (hdr) {
      out.challenge = await decodeChallenge(hdr.replace(/^v2:/, ""));
    } else {
      let txt = "";
      try {
        txt = await res.text();
      } catch (e) {}
      try {
        out.challenge = { x402Version: JSON.parse(txt).x402Version, raw_body: txt.slice(0, 4000) };
      } catch (e) {
        out.challenge = { raw_body: txt.slice(0, 4000) };
      }
    }
  } else {
    out.note = "endpoint did not answer 402, so it is either free or not an x402 resource";
  }
  return out;
}

const FACILITATORS = ["https://facilitator.payai.network", FACILITATOR];

async function settleOne(fac, payload, requirements) {
  const body = { x402Version: 2, paymentPayload: payload, paymentRequirements: requirements };
  const r = await fetch(fac + "/settle", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const text = await r.text();
  let out;
  try { out = JSON.parse(text); } catch (e) { out = { raw: text.slice(0, 500) }; }
  return { status: r.status, result: out, facilitator: fac };
}

async function settleVia(payload, requirements) {
  let last = null;
  for (const fac of FACILITATORS) {
    try {
      const v = await settleOne(fac, payload, requirements);
      const ok = v.status === 200 && v.result && (v.result.success === true || v.result.settled === true);
      if (ok) return v;
      last = v;
      // a nonce already used means it settled elsewhere or is a replay; do not retry
      if (JSON.stringify(v.result).match(/nonce|already|used/i)) return v;
    } catch (e) { last = { status: 0, result: { error: String(e).slice(0, 200) }, facilitator: fac }; }
  }
  return last;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const base = url.origin;
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

    if (path === "/health") {
      return json({ ok: true, service: "x402-probe", network: NETWORK, price: PRICE, facilitator: FACILITATOR });
    }
    if (path === "/") {
      return json({
        service: "x402-probe",
        paid: PAID,
        free: ["/health", "/.well-known/x402", "/.well-known/x402.json", "/openapi.json"],
        network: NETWORK,
        price: PRICE,
        payTo: PAY_TO,
      });
    }
    if (path === "/.well-known/x402") {
      return json({
        version: 1,
        resources: [base + "/probe?url=https://hermes.swap.io/v1/swap/quote", base + "/price/ETH"],
        ownershipProofs: [PAY_TO],
        instructions:
          "GET /probe?url=<paid-endpoint> returns that endpoint's x402 challenge (price/network/asset/payTo) without paying it. Handles v2 header and v1 JSON-body challenges.",
      });
    }
    if (path === "/.well-known/x402.json" || path === "/.well-known/x402-v2.json") {
      const mk = (p, d) => ({
        resource: base + p,
        type: "http",
        x402Version: 2,
        lastUpdated: new Date().toISOString(),
        accepts: challenge(base + p, d).accepts,
        metadata: { description: d, input: { type: "http", method: "GET" } },
      });
      return json({
        x402Version: 2,
        items: [mk("/probe", PAID["/probe"]), mk("/fetch", PAID["/fetch"]), mk("/wiki", PAID["/wiki"]), mk("/price/ETH", PAID["/price/ETH"])],
        ownershipProofs: [PAY_TO],
        instructions: "Pay 0.001 USDC on Base per call; retry with the PAYMENT-SIGNATURE header.",
      });
    }
    if (path === "/openapi.json") {
      const op = (id, summary, body) => ({
        operationId: id,
        summary,
        "x-payment-info": { protocols: [{ x402: {} }], price: { mode: "fixed", currency: "USD", amount: "0.001" } },
        requestBody: body,
        responses: { 200: { description: "Result" }, 402: { description: "Payment required" } },
      });
      return json({
        openapi: "3.1.0",
        info: { title: "x402 Probe", version: "1.5.0", contact: { email: "ernest-earnordie@agentmail.to", name: "Ernest", url: "https://earnordie-ernest.github.io/x402-seller-kit/" }, description: "Paid x402 utility API. POST /probe with {url} returns any endpoint's x402 price/network/asset/payTo without paying it. $0.001 USDC on Base per call." },
        servers: [{ url: base }],
        paths: {
          "/probe": {
            post: op("probeEndpoint", "Decode any endpoint's x402 price, network, asset and payTo without paying it. $0.001 USDC on Base.", {
              required: true,
              content: { "application/json": { schema: { type: "object", required: ["url"], properties: { url: { type: "string", format: "uri", description: "https URL of the x402 endpoint to decode" } } } } },
            }),
          },
          "/fetch": {
            post: op("fetchPage", "Fetch any public web page; returns clean readable text, title and links for LLM agents. $0.001 USDC on Base.", {
              required: true,
              content: { "application/json": { schema: { type: "object", required: ["url"], properties: { url: { type: "string", format: "uri", description: "http(s) URL of the page to fetch" } } } } },
            }),
          },
          "/wiki": {
            post: op("wikiSummary", "Wikipedia summary of any topic: title, plain-text extract and canonical URL. $0.001 USDC on Base.", {
              required: true,
              content: { "application/json": { schema: { type: "object", required: ["q"], properties: { q: { type: "string", description: "topic or page title" }, lang: { type: "string", description: "wiki language code, default en" } } } } },
            }),
          },
          "/price/ETH": {
            post: op("ethPrice", "ETH/USD spot price. $0.001 USDC on Base.", {
              required: false,
              content: { "application/json": { schema: { type: "object", properties: { symbol: { type: "string", description: "always ETH" } } } } },
            }),
          },
        },
        "x-discovery": { ownershipProofs: [PAY_TO] },
      });
    }

    // ---- paid routes ----
    const desc = PAID[path];
    if (desc) {
      const payloadHeader = request.headers.get("payment-signature") || request.headers.get("x-payment");
      const ch = challenge(url.toString(), desc);
      if (!payloadHeader) {
        return paymentRequired(ch);
      }
      let payload;
      try {
        payload = b64decode(payloadHeader.replace(/^v2:/, ""));
      } catch (e) {
        return json({ error: "malformed payment payload" }, 402, { "payment-required": b64encode(ch) });
      }
      const reqs = ch.accepts[0];
      const v = await settleVia(payload, reqs);
      const okv = v.result && (v.result.success === true || v.result.settled === true || v.result.valid === true);
      if (v.status !== 200 || !okv) {
        return json({ error: "payment not settled", facilitator: v }, 402, {
          "payment-required": b64encode(ch),
        });
      }
      const receipt = b64encode(v.result);
      let body;
      if (path === "/probe") {
        let target = url.searchParams.get("url");
        if (!target && request.method === "POST") {
          try { target = (await request.clone().json()).url; } catch (e) {}
        }
        body = target ? await probeTarget(target) : { ok: false, error: "missing url (?url= or JSON body {url})" };
      } else if (path === "/fetch") {
        let target = url.searchParams.get("url");
        if (!target && request.method === "POST") {
          try { target = (await request.clone().json()).url; } catch (e) {}
        }
        body = target ? await fetchClean(target) : { ok: false, error: "missing url (?url= or JSON body {url})" };
      } else if (path === "/wiki") {
        let q = url.searchParams.get("q");
        if (!q && request.method === "POST") { try { const j = await request.clone().json(); q = j.q || j.title; } catch (e) {} }
        body = q ? await wikiSummary(q, url.searchParams.get("lang")) : { ok: false, error: "missing q (?q= or JSON body {q})" };
      } else if (path === "/price/ETH") {
        let price = null;
        try {
          const r = await fetch("https://api.coinbase.com/v2/prices/ETH-USD/spot");
          price = (await r.json()).data;
        } catch (e) {}
        body = { symbol: "ETH/USD", spot: price, source: "coinbase", at: new Date().toISOString() };
      }
      return json({ paid: true, receipt: v.result, result: body }, 200, { "payment-response": receipt });
    }

    return json({ error: "not found", service: "x402-probe" }, 404);
  },
};
